package CarreraDeCaballos;

import CarreraDeCaballos.Model.*;
import CarreraDeCaballos.Model.Tablero;
import java.util.*;

public class CarreraCaballos {
    private Crupier crupier;
    private Caballo[] caballos;
     private Scanner scanner;
    private Set<Caballo> caballosEscogidos;
    private int contadorRondas;
    private boolean retrocederProximo;
    private int retrocesosPermitidos;
    private Tablero tablero;
    private JugadorCarreraCaballos jugador;

    public CarreraCaballos() {
        this.scanner = new Scanner(System.in);
        System.out.println("Hola, introduce tu nombre:");
        inicializarJuego(scanner.nextLine());
    }

    private void inicializarJuego(String nombreJugador) {
        // Inicializa los caballos disponibles
        this.caballos = new Caballo[] {
                new Caballo("Caballo de Bastos", TipoCarta.BASTOS),
                new Caballo("Caballo de Oros", TipoCarta.OROS),
                new Caballo("Caballo de Espadas", TipoCarta.ESPADAS),
                new Caballo("Caballo de Copas", TipoCarta.COPAS)
        };

        // Crear instancia del jugador con el caballo inicial
        Caballo caballoInicial = caballos[0]; // Por ejemplo, puedes elegir el primer caballo por defecto
        this.jugador = new JugadorCarreraCaballos(nombreJugador, caballoInicial);

        // Inicializa el crupier y otros elementos
        this.crupier = new Crupier();
        this.tablero = new Tablero(caballos);
        this.caballosEscogidos = new HashSet<>();
        this.contadorRondas = 0;
        this.retrocederProximo = false;
        this.retrocesosPermitidos = 6;
    }

    public ResultadoRonda jugarRonda() {
        if (caballos == null || caballos.length == 0) {
            throw new IllegalStateException("No hay caballos en la carrera.");
        }

        // Sacar carta del crupier de manera aleatoria
        TipoCarta tipoAleatorio = TipoCarta.getRandomTipo();  // Obtener tipo de carta aleatorio
        Carta carta = new Carta(tipoAleatorio);  // Crear la carta con el tipo aleatorio


        String efecto = ""; // Descripción del efecto para mostrar en la interfaz
        if (carta != null) {
            System.out.println("El crupier ha sacado la carta: " + carta);

            if (retrocederProximo && retrocesosPermitidos > 0) {
                for (Caballo caballo : caballos) {
                    if (caballo.getTipoCarta() == carta.getTipoCarta()) {
                        caballo.retroceder();
                        efecto = caballo.getNombre() + " retrocede una posición.";
                        retrocesosPermitidos--;
                        break;
                    }
                }
                retrocederProximo = false;
            } else {
                for (Caballo caballo : caballos) {
                    if (caballo.getTipoCarta() == carta.getTipoCarta()) {
                        caballo.avanzar();
                        efecto = caballo.getNombre() + " avanza una posición.";
                    }
                }
                contadorRondas++;
                if (contadorRondas % 4 == 0) {
                    retrocederProximo = true;
                }
            }
        }

        // Verificar si hay un ganador
        Caballo ganador = Arrays.stream(caballos)
                .filter(caballo -> caballo.getPosicion() == 9)
                .findFirst()
                .orElse(null);

        return new ResultadoRonda(contadorRondas, carta, efecto, caballos, ganador);
    }
}

