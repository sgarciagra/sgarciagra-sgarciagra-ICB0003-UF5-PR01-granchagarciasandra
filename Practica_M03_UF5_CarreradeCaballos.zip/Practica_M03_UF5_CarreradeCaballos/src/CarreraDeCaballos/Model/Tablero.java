package CarreraDeCaballos.Model;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

public class Tablero {
    private Caballo[] caballos;

    public Tablero(Caballo[] caballos) {
        this.caballos = caballos;
    }

    // Método para obtener las posiciones actuales de los caballos
    public int[] obtenerPosiciones() {
        int[] posiciones = new int[caballos.length];

        // Obtener las posiciones de cada caballo
        for (int i = 0; i < caballos.length; i++) {
            posiciones[i] = caballos[i].getPosicion();  // Obtiene la posición del caballo
        }
        return posiciones;
    }

    // Método para actualizar el tablero visualmente
    public void actualizarTablero(GridPane tablero) {
        // Limpiar el tablero (para evitar superposiciones de imágenes)
        tablero.getChildren().clear();

        // Colocar las imágenes de los caballos en sus nuevas posiciones
        for (Caballo caballo : caballos) {
            ImageView imagenCaballo = new ImageView(getImageForCaballo(caballo));  // Asume que tienes un método para obtener la imagen del caballo
            GridPane.setColumnIndex(imagenCaballo, caballo.getPosicion());  // Coloca la imagen del caballo en su columna
            GridPane.setRowIndex(imagenCaballo, obtenerFilaCaballo(caballo));  // Coloca la imagen en la fila correspondiente
            tablero.getChildren().add(imagenCaballo);  // Añadir la imagen al tablero
        }
    }

    // Método auxiliar para obtener la fila correspondiente al tipo de caballo
    private int obtenerFilaCaballo(Caballo caballo) {
        switch (caballo.getTipoCarta()) {
            case BASTOS: return 0;
            case OROS: return 1;
            case ESPADAS: return 2;
            case COPAS: return 3;
            default: return -1;
        }
    }

    // Método auxiliar para obtener la imagen correspondiente a cada caballo
    private Image getImageForCaballo(Caballo caballo) {
        switch (caballo.getTipoCarta()) {
            case BASTOS: return new Image(getClass().getResource("/ImagenCaballoBastos.jpg").toString());
            case OROS: return new Image(getClass().getResource("/ImagenCaballoOros.jpg").toString());
            case ESPADAS: return new Image(getClass().getResource("/ImagenCaballoEspadas.jpg").toString());
            case COPAS: return new Image(getClass().getResource("/ImagenCaballoCopas.jpg").toString());
            default: return null;
        }
    }

    // Método adicional para resetear las posiciones de los caballos (opcional)
    public void resetTablero() {
        for (Caballo caballo : caballos) {
            caballo.setPosicion(0);  // Resetea la posición de todos los caballos a 0
        }
    }

    // Método adicional para actualizar la posición de un caballo específico
    public void actualizarPosicionCaballo(Caballo caballo, int nuevaPosicion) {
        caballo.setPosicion(nuevaPosicion);
    }

    // Método adicional para obtener un caballo por su posición (opcional)
    public Caballo obtenerCaballoPorPosicion(int posicion) {
        for (Caballo caballo : caballos) {
            if (caballo.getPosicion() == posicion) {
                return caballo;
            }
        }
        return null;  // Si no se encuentra, devuelve null
    }
}





