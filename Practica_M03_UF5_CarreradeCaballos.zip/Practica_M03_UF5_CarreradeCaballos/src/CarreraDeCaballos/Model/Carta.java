package CarreraDeCaballos.Model;

public class Carta {
    private TipoCarta tipoCarta; // Tipo de Carta (Bastos, Oros, Copas y Espadas)

    // Constructor que acepta un TipoCarta
    public Carta(TipoCarta tipoCarta) {
        this.tipoCarta = tipoCarta;
    }

    // Getter para obtener el tipo de carta
    public TipoCarta getTipoCarta() {
        return tipoCarta;
    }

    @Override
    public String toString() {
        String tipo = "";
        switch (tipoCarta) {
            case BASTOS:
                tipo = "Caballo de Bastos";
                break;
            case OROS:
                tipo = "Caballo de Oros";
                break;
            case ESPADAS:
                tipo = "Caballo de Espadas";
                break;
            case COPAS:
                tipo = "Caballo de Copas";
                break;
            default:
                break;
        }
        return tipo;  // Devuelve el valor correcto
    }
}

