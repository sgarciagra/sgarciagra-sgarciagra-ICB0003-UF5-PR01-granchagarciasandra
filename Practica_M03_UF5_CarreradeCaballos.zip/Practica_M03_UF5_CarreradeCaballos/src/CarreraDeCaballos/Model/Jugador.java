package CarreraDeCaballos.Model;

public interface Jugador {

    void hacerApuesta(Caballo caballo, int fichas);

    void anunciarGanador(Caballo caballo);

    void recibirBote(int fichas);

    String getNombre();

    // Añadimos el método para obtener el caballo elegido
    Caballo getCaballoElegido();
}


