package CarreraDeCaballos.Model;

import java.util.Random;

public enum TipoCarta {
    BASTOS,
    OROS,
    ESPADAS,
    COPAS;

    // Método para obtener un TipoCarta aleatorio
    public static TipoCarta getRandomTipo() {
        Random rand = new Random();
        return values()[rand.nextInt(values().length)];
    }
}

