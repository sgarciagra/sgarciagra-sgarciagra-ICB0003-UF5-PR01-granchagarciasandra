package CarreraDeCaballos.Model;

public class ResultadoRonda {
    private int numeroRonda;
    private Carta cartaCrupier;
    private String efecto;
    private Caballo[] caballos;
    private Caballo ganador;
    private int bote;

    public ResultadoRonda(int numeroRonda, Carta cartaCrupier, String efecto, Caballo[] caballos, Caballo ganador) {
        this.numeroRonda = numeroRonda;
        this.cartaCrupier = cartaCrupier;
        this.efecto = efecto;
        this.caballos = caballos;
        this.ganador = ganador;
        this.bote = 0;  // Inicialización del bote
    }

    public int getNumeroRonda() {
        return numeroRonda;
    }

    public Carta getCartaCrupier() {
        return cartaCrupier;
    }

    public String getEfecto() {
        return efecto;
    }

    public Caballo[] getCaballos() {
        return caballos;
    }

    public Caballo getGanador() {
        return ganador;
    }

    public int getBote() {
        return bote;
    }

    public void actualizarBote(int cantidad) {
        this.bote += cantidad;
    }
}

