package CarreraDeCaballos.Model;

public class Caballo {
    private String nombre;          // Nombre del caballo
    private TipoCarta tipoCarta;    // Tipo de carta asociada al caballo
    private int posicion;           // Posición actual del caballo (ya no es estática)
    private int[] posiciones;       // Historial de posiciones del caballo
    private Runnable callbackFinCarrera; // Callback para notificar el fin de la carrera

    // Constructor que recibe el nombre y el tipo de carta
    public Caballo(String nombre, TipoCarta tipoCarta) {
        this.nombre = nombre;
        this.tipoCarta = tipoCarta;
        this.posiciones = new int[10];  // Inicializa el historial de posiciones
        this.posicion = 0;              // Inicializa la posición del caballo en 0
        System.out.println("Caballo creado: " + nombre + " con tipo de carta: " + tipoCarta);  // Depuración
    }

    // Getter para obtener el nombre del caballo
    public String getNombre() {
        return nombre;
    }

    // Getter para obtener el tipo de carta asociada al caballo
    public TipoCarta getTipoCarta() {
        return tipoCarta;
    }

    // Getter para obtener la posición actual del caballo
    public int getPosicion() {
        return posicion;
    }

    // Establece la posición del caballo en el tablero
    public void setPosicion(int posicion) {
        if (posicion >= 0 && posicion < posiciones.length) {  // Asegura que la posición es válida
            this.posicion = posicion;
        } else {
            System.out.println("Posición no válida: " + posicion);
        }
    }

    // Establece el callback para el fin de la carrera
    public void setCallbackFinCarrera(Runnable callback) {
        this.callbackFinCarrera = callback;
    }

    // El caballo avanza una posición en el tablero
    public void avanzar() {
        if (posicion < 9) {  // Verifica que el caballo no sobrepase la meta
            posicion++;      // Avanza una posición
        }
        // Si el caballo ha llegado a la meta (posición 9), ejecuta el callback
        if (posicion == 9 && callbackFinCarrera != null) {
            callbackFinCarrera.run();
        }
    }

    // El caballo retrocede una posición en el tablero
    public void retroceder() {
        if (posicion > 0) {  // Verifica que la posición no sea negativa
            posicion--;      // Retrocede una posición
        }
    }

    // Método para obtener el historial de posiciones del caballo
    public int[] getPosiciones() {
        return posiciones;
    }

    // Actualiza el historial de posiciones del caballo
    public void actualizarPosicionHistorial() {
        if (posicion >= 0 && posicion < posiciones.length) {
            posiciones[posicion] = posicion;  // Guarda la posición en el historial
        }
    }

    // Método para representar al caballo como una cadena de texto
    @Override
    public String toString() {
        String tipo = "";
        switch (tipoCarta) {
            case BASTOS:
                tipo = "Caballo de Bastos";
                break;
            case OROS:
                tipo = "Caballo de Oros";
                break;
            case ESPADAS:
                tipo = "Caballo de Espadas";
                break;
            case COPAS:
                tipo = "Caballo de Copas";
                break;
            default:
                break;
        }
        return nombre + " (" + tipo + ") - Posición: " + posicion;
    }
}



