package CarreraDeCaballos.Model;

public class JugadorCarreraCaballos extends JugadorBase implements Jugador {
    private Caballo caballoElegido;
    private String nombre;
    private JugadorCarreraCaballos jugador;

    public JugadorCarreraCaballos(String nombre, Caballo caballoElegido) {
        this.nombre = nombre;
        this.caballoElegido = caballoElegido;
    }

    // Implementación del método anunciarGanador de la interfaz Jugador
    @Override
    public void anunciarGanador(Caballo caballo) {
        System.out.println("El " + caballo.getNombre() + " ha ganado la carrera ");
    }

    // Implementación del método recibirBote de la interfaz Jugador
    @Override
    public void recibirBote(int fichas) {
        System.out.println(nombre + " ha ganado el bote de " + fichas + " €");
    }

    // Implementación del método hacerApuesta de la interfaz Jugador
    @Override
    public void hacerApuesta(Caballo caballo, int fichas) {
        this.caballoElegido = caballo;
        System.out.println(nombre + " ha apostado en " + caballo.getNombre() + " con " + fichas + " €");
    }

    public String getNombre() {
        return nombre;
    }

    public Caballo getCaballoElegido() {
        return caballoElegido;
    }
}
