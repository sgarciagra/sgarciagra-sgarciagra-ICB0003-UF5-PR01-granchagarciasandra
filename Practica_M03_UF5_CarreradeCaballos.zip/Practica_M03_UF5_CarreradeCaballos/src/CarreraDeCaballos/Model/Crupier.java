package CarreraDeCaballos.Model;
public class Crupier {
    private Baraja baraja;

    //public Crupier() {
        //this.baraja = new Baraja();
    //}

    //public Baraja getBaraja() {
        //return this.baraja;
    //}

    public Carta sacarCarta() {
        //if (baraja.estaVacia()) {
            //System.out.println("La baraja está vacía.");
           //return null;  // O lanzar una excepción si prefieres eso
        //}

        // Usamos getRandomTipo() para elegir un tipo de carta aleatorio
        TipoCarta tipoCartaAleatorio = TipoCarta.getRandomTipo();

        // Crear una carta con ese tipo aleatorio
        return new Carta(tipoCartaAleatorio);
    }
}




