package CarreraDeCaballos.Utils;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

public class PantallaGanadorController {


    @FXML private Label mensajeRonda;  // Mensaje de la ronda
    @FXML private ImageView imagenCartaGanadora;
    @FXML private Label labelCaballoGanador;
    @FXML private Label valorCrupier;
    private java.awt.Label vboxCrupier;


    // Método para inicializar la pantalla con la información del ganador


    public void inicializarPantalla(Label valorCrupierLabel, String mensajeRonda) {
        if (this.valorCrupier != null) {
            valorCrupierLabel.setText("El caballo ganador es: " + this.valorCrupier);
        } else {
            valorCrupierLabel.setText("Caballo ganador no disponible.");
        }

        if (mensajeRonda != null) {
            this.mensajeRonda.setText(mensajeRonda);
        } else {
            this.mensajeRonda.setText("Mensaje de ronda no disponible.");
        }
    }


    // Método para volver al menú principal
     @FXML
    public void volverMenu(ActionEvent event) {
        try {
            // Obtener la ventana actual (emergente)
            Stage stageEmergente = (Stage) ((Button) event.getSource()).getScene().getWindow();

            // Cerrar la ventana emergente actual (PantallaGanador)
            stageEmergente.close();


            // Cargar la pantalla de bienvenida
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/CarreraDeCaballos/Utils/Pantalla_Bienvenida_CarreradeCaballos.fxml"));
            Scene escenaBienvenida = new Scene(loader.load());
            Stage stageBienvenida = new Stage();
            stageBienvenida.setScene(escenaBienvenida);
            stageBienvenida.setTitle("CARRERA DE CABALLOS");

            // Mostrar la pantalla de bienvenida
            stageBienvenida.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}



