package CarreraDeCaballos.Utils;

import CarreraDeCaballos.Model.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class PantallaInicioPartidaController {

    // Referencias a los elementos de la interfaz
    @FXML
    private Label nombreJugadorLabel;
    @FXML
    private Label apuestaInicialLabel;
    @FXML
    private Label caballoSeleccionadoLabel;

    @FXML
    private GridPane tablero;

    @FXML
    private VBox valorCrupier;
    @FXML
    private VBox valorEfecto;
    @FXML
    private Button botonJugarRonda;
    @FXML
    private ImageView imagenCarriles;
    @FXML
    private ImageView imagenCartaGanadora;
    @FXML private Stage stage;
    @FXML
    private Label mensajeRonda;
    @FXML
    private Button volverMenu;




    // Variables para la lógica del juego

    private Tablero tableroJuego;
    private Crupier crupier;
    private Caballo[] caballos;
    private int ronda;
    private PantallaConfiguracionController configController;
    private Caballo caballoSeleccionado;
    private Caballo cartaCrupier;
    private Object valorCrupierLabel;


    public void initialize() {
        cargarImagenCarriles();
        crupier = new Crupier();
        ronda = 0;
        configurarJuego();
    }

    private void cargarImagenCarriles() {
        URL imagenURL = getClass().getResource("/ImagenCarriles.jpg");
        if (imagenURL != null) {
            Image imagen = new Image(imagenURL.toExternalForm());
            imagenCarriles.setImage(imagen);
        } else {
            System.err.println("No se pudo cargar la imagen de los carriles.");
        }
    }

    public void cargarDatosInicioPartida(String nombreJugador, String apuestaInicialStr, String caballoSeleccionado) {
        nombreJugadorLabel.setText("Juega " + nombreJugador);
        apuestaInicialLabel.setText("con " + apuestaInicialStr + "€");
        caballoSeleccionadoLabel.setText("a " + caballoSeleccionado);
    }

    public void configurarJuego() {
        tablero.setAlignment(javafx.geometry.Pos.CENTER);
        caballos = new Caballo[]{
                new Caballo("Caballo de Bastos", TipoCarta.BASTOS),
                new Caballo("Caballo de Oros", TipoCarta.OROS),
                new Caballo("Caballo de Espadas", TipoCarta.ESPADAS),
                new Caballo("Caballo de Copas", TipoCarta.COPAS)
        };
        tableroJuego = new Tablero(caballos);
        actualizarTablero();
    }


    private void actualizarTablero() {
        int[] posiciones = tableroJuego.obtenerPosiciones();
        tablero.getChildren().removeIf(node -> node instanceof ImageView);
        for (int i = 0; i < caballos.length; i++) {
            ImageView imagenCaballo = obtenerImagenCaballo(caballos[i]);
            imagenCaballo.setFitHeight(30);
            imagenCaballo.setFitWidth(30);
            colocarImagenEnTablero(caballos[i], imagenCaballo, posiciones[i]);
        }
    }

    private void colocarImagenEnTablero(Caballo caballo, ImageView imagen, int posicion) {
        int fila = obtenerFilaCaballo(caballo);
        GridPane.setColumnIndex(imagen, posicion);
        GridPane.setRowIndex(imagen, fila);
        GridPane.setHalignment(imagen, javafx.geometry.HPos.CENTER);
        GridPane.setValignment(imagen, javafx.geometry.VPos.CENTER);
        tablero.getChildren().add(imagen);
    }

    private ImageView obtenerImagenCaballo(Caballo caballo) {
        String path = switch (caballo.getTipoCarta()) {
            case BASTOS -> "/ImagenCaballoBastos.jpg";
            case OROS -> "/ImagenCaballoOros.jpg";
            case ESPADAS -> "/ImagenCaballoEspadas.jpg";
            case COPAS -> "/ImagenCaballoCopas.jpg";
        };
        URL imagenURL = getClass().getResource(path);
        if (imagenURL != null) {
            return new ImageView(new Image(imagenURL.toExternalForm()));
        } else {
            System.err.println("No se pudo cargar la imagen para el " + caballo.getTipoCarta());
            return new ImageView();
        }
    }

    private int obtenerFilaCaballo(Caballo caballo) {
        return switch (caballo.getTipoCarta()) {
            case BASTOS -> 0;
            case OROS -> 1;
            case ESPADAS -> 2;
            case COPAS -> 3;
        };
    }

    @FXML
    private void jugarRonda(ActionEvent event) {
        ronda++;
        Carta carta = crupier.sacarCarta();
        valorCrupier.getChildren().clear();
        valorCrupier.getChildren().add(new Label(carta.toString()));
        valorEfecto.getChildren().clear();

        if (ronda % 4 == 0) {
            for (Caballo caballo : caballos) {
                if (caballo.getTipoCarta() == carta.getTipoCarta()) {
                    caballo.retroceder();
                    valorEfecto.getChildren().add(new Label("El caballo de " + carta.getTipoCarta() + " retrocede 1 posición."));
                    break;
                }
            }
        } else {
            for (Caballo caballo : caballos) {
                if (caballo.getTipoCarta() == carta.getTipoCarta()) {
                    caballo.avanzar();
                    valorEfecto.getChildren().add(new Label("El caballo de " + carta.getTipoCarta() + " avanza 1 posición."));
                }
            }
        }
        actualizarTablero();

        // Verificar si algún caballo alcanzó la posición 9
        for (Caballo caballo : caballos) {
            if (caballo.getPosicion() == 9) {
                System.out.println("El caballo " + caballo.getNombre() + " ha ganado la carrera!");
                String mensajeRonda = "¡El caballo " + valorCrupier + " ha ganado la carrera!";
                mostrarPantallaGanador(caballo, mensajeRonda);
                return; // Salir del método después de mostrar la pantalla de ganador
            }
        }
    }

    @FXML
    private void mostrarPantallaGanador(final Caballo caballoGanador, final String mensajeRonda) {
        Platform.runLater(() -> {
            try {
                // Cargar el archivo FXML
                System.out.println("Intentando cargar el archivo FXML...");
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/CarreraDeCaballos/Utils/Pantalla_Ganador_Ronda.fxml"));
                Parent root = loader.load();  // Intenta cargar el FXML
                // Verifica que el controlador se ha cargado correctamente
                PantallaGanadorController ganadorController = loader.getController();
                if (ganadorController == null) {
                    System.err.println("Error: El controlador no se cargó correctamente.");
                } else {
                    System.out.println("Controlador cargado correctamente.");

                    // Inicializa la pantalla con el caballo ganador y el mensaje
                    Platform.runLater(() -> {
                        ganadorController.inicializarPantalla((Label) valorCrupierLabel, mensajeRonda);
                    });
                }

                // Crear y mostrar la nueva ventana
                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.setTitle("Ganador de la Carrera");
                stage.show();

            } catch (IOException e) {
                System.err.println("Error al cargar la pantalla: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }




}










