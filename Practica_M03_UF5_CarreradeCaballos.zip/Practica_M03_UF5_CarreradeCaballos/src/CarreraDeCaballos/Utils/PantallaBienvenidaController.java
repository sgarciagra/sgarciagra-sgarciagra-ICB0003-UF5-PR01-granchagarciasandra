package CarreraDeCaballos.Utils;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class PantallaBienvenidaController {

    // Declarar el ImageView con la anotación @FXML
    @FXML
    private ImageView backgroundImage;

    // Método de inicialización
    @FXML
    public void initialize() {
        // Cargar la imagen de forma explícita
        URL imageUrl = getClass().getResource("/ImagenFondoBienvenida.jpg");
        if (imageUrl != null) {
            Image image = new Image(imageUrl.toString());
            backgroundImage.setImage(image);
        } else {
            System.out.println("Error: La imagen no se encuentra en la ruta especificada.");
        }
    }


    @FXML
    public void handleEmpezarPartida(ActionEvent event) throws IOException {
        // Cargar la pantalla de configuración
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/CarreraDeCaballos/Utils/Pantalla_Configuracion_CarreradeCaballos.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void handleVerEstadisticas(ActionEvent event) {
        // Mostrar estadísticas
    }

    @FXML
    public void handleSalir(ActionEvent event) {
        System.exit(0);
    }
}

