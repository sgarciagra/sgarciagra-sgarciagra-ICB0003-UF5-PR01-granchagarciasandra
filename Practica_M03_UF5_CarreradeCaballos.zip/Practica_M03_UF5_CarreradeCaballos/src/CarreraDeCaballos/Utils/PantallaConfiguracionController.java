package CarreraDeCaballos.Utils;

import CarreraDeCaballos.Model.Caballo;
import CarreraDeCaballos.Model.JugadorCarreraCaballos;
import CarreraDeCaballos.Model.TipoCarta;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class PantallaConfiguracionController extends Label {

    @FXML
    private TextField campoNombre;
    @FXML
    private TextField campoApuesta;
    @FXML
    private ComboBox<Caballo> campoApuestaCaballo;
    @FXML
    private Button botonInicioDePartida;

    private Caballo caballoElegido(String nombreCaballo) {
        switch (nombreCaballo) {
            case "Caballo de Bastos":
                return new Caballo("Caballo de Bastos", TipoCarta.BASTOS);
            case "Caballo de Oros":
                return new Caballo("Caballo de Oros", TipoCarta.OROS);
            case "Caballo de Espadas":
                return new Caballo("Caballo de Espadas", TipoCarta.ESPADAS);
            case "Caballo de Copas":
                return new Caballo("Caballo de Copas", TipoCarta.COPAS);
            default:
                throw new IllegalArgumentException("Caballo no válido: " + nombreCaballo);
        }
    }


    public Caballo getCaballoSeleccionado() {
        return campoApuestaCaballo.getValue();
    }


    @FXML
    private void handleInicioDePartida() {
        String nombreJugador = campoNombre.getText();
        String apuestaInicialStr = campoApuesta.getText();
        String caballoSeleccionado = String.valueOf(campoApuestaCaballo.getValue());
        int apuestaInicial = 0;

        if (nombreJugador.isEmpty() || apuestaInicialStr.isEmpty()) {
            System.out.println("Por favor, completa todos los campos.");
            return;
        }

        try {
            apuestaInicial = Integer.parseInt(apuestaInicialStr);
        } catch (NumberFormatException e) {
            System.out.println("La apuesta debe ser un número válido.");
            return;
        }

        if (caballoSeleccionado == null) {
            System.out.println("Por favor, selecciona un caballo.");
            return;
        }

        System.out.println("Iniciando partida para: " + nombreJugador +
                " con una apuesta inicial de: " + apuestaInicial +
                "€ en el caballo: " + caballoSeleccionado);

        // Crear el caballo elegido (usando el método caballoElegido que ya tienes)
        Caballo caballo = caballoElegido(caballoSeleccionado);

        // Crear el jugador con el nombre
        JugadorCarreraCaballos jugador = new JugadorCarreraCaballos(nombreJugador, caballo);
        jugador.hacerApuesta(caballo, apuestaInicial); // El jugador hace la apuesta


        // Cargar la siguiente pantalla (Pantalla de Inicio de Carrera)
        try {
            // Asegúrate de que la ruta es correcta
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/CarreraDeCaballos/Utils/Pantalla_InicioPartida_CarreradeCaballos.fxml"));
            Parent root = loader.load(); // Carga la pantalla

            // Obtener el controlador de la siguiente pantalla
            PantallaInicioPartidaController controladorCarrera = loader.getController();

            // Asegúrate de que los datos pasados sean correctos
            controladorCarrera.cargarDatosInicioPartida(nombreJugador, apuestaInicialStr, caballoSeleccionado);

            // Cambiar la escena a la pantalla de la carrera
            Stage stage = (Stage) botonInicioDePartida.getScene().getWindow();
            Scene escena = new Scene(root);
            stage.setScene(escena);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace(); // Captura la excepción si ocurre un problema al cargar el FXML
        } catch (Exception e) {
            // Si ocurre otro tipo de excepción, también la capturamos
            e.printStackTrace();
        }

    }
}





