package CarreraDeCaballos;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        // Cargar el archivo FXML y verificar si está accesible en el classpath
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/CarreraDeCaballos/Utils/Pantalla_Bienvenida_CarreradeCaballos.fxml"));
        Parent root = fxmlLoader.load();  // Cargar el contenido del FXML

        // Crear la escena y asignar la escena al escenario
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Carrera de Caballos"); // Opcional, título de la ventana
        stage.show();  // Mostrar la ventana
    }

    public static void main(String[] args) {
        launch(args);  // Iniciar la aplicación JavaFX
    }
}




