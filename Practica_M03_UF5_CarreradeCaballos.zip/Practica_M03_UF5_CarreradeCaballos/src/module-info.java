module Practica_M03_UF5_CarreradeCaballos {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.base;
    requires java.desktop; // Asegúrate de incluir todos los módulos necesarios para JavaFX

    opens CarreraDeCaballos.Utils to javafx.fxml; // Abre el paquete para que se pueda acceder a los controladores desde FXML
    exports CarreraDeCaballos; // Exporta el paquete principal si es necesario
}

